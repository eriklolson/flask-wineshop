from flask import url_for, request,render_template
from flask_wineshop.cart.helpers import get_no_of_items
from flask_wineshop.models import *
from . import bp


# @bp.route('/products')
# def products():
#     r = requests.get('http://localhost:5000/api/bottles')
#     bottles = json.loads(r.text)
#     return render_template(bottles=bottles)


@bp.route('/wine')
def wine():
    page = request.args.get('page', 1, type=int)
    no_of_items = get_no_of_items()
    bottles = db.session.query(Bottles).order_by(Bottles.description.desc()).paginate(
        page, app.config['WINES_PER_PAGE'], False)
    colors = Bottles.query.with_entities(Bottles.color_name).distinct().order_by(Bottles.color_name.asc())
    varietals = Bottles.query.with_entities(Bottles.primary_grape).distinct().order_by(Bottles.primary_grape.asc())
    countries = Countries.query.with_entities(Countries.country_name).distinct().order_by(Countries.country_name.asc())
    regions = Regions.query.with_entities(Regions.region_name).distinct().order_by(Regions.region_name.asc())
    next_url = url_for('products.wine', page=bottles.next_num) if bottles.has_next else None
    prev_url = url_for('products.wine', page=bottles.prev_num) if bottles.has_prev else None
    return render_template("wine.jinja2", bottles=bottles.items, countries=countries, colors=colors,
                           varietals=varietals, regions=regions, next_url=next_url, prev_url=prev_url,
                           no_of_items=no_of_items)


@bp.route('/color/<color_name>')
def color(color_name):
    page = request.args.get('page', 1, type=int)
    no_of_items = get_no_of_items()
    bottles = db.session.query(Bottles).filter_by(color_name=color_name).paginate(
        page, app.config['WINES_PER_PAGE'], False)
    colors = Bottles.query.with_entities(Bottles.color_name).distinct().order_by(Bottles.color_name.asc())
    varietals = Bottles.query.with_entities(Bottles.primary_grape).distinct().order_by(Bottles.primary_grape.asc())
    countries = Countries.query.with_entities(Countries.country_name).distinct().order_by(Countries.country_name.asc())
    regions = Regions.query.with_entities(Regions.region_name).distinct().order_by(Regions.region_name.asc())
    next_url = url_for('products.color', color_name=color_name, page=bottles.next_num) if bottles.has_next else None
    prev_url = url_for('products.color', color_name=color_name, page=bottles.prev_num) if bottles.has_prev else None
    return render_template('results.jinja2', bottles=bottles.items, countries=countries, colors=colors,
                           varietals=varietals, regions=regions, next_url=next_url, prev_url=prev_url,
                           no_of_items=no_of_items)


@bp.route('/varietal/<primary_grape>')
def varietal(primary_grape):
    page = request.args.get('page', 1, type=int)
    no_of_items = get_no_of_items()
    bottles = db.session.query(Bottles).filter_by(primary_grape=primary_grape).paginate(
        page, app.config['WINES_PER_PAGE'], False)
    colors = Bottles.query.with_entities(Bottles.color_name).distinct().order_by(Bottles.color_name.asc())
    varietals = Bottles.query.with_entities(Bottles.primary_grape).distinct().order_by(Bottles.primary_grape.asc())
    countries = Countries.query.with_entities(Countries.country_name).distinct().order_by(Countries.country_name.asc())
    regions = Regions.query.with_entities(Regions.region_name).distinct().order_by(Regions.region_name.asc())
    next_url = url_for('products.varietal', primary_grape=varietal, page=bottles.next_num) if bottles.has_next else None
    prev_url = url_for('products.varietal', primary_grape=varietal, page=bottles.prev_num) if bottles.has_prev else None
    return render_template('results.jinja2', bottles=bottles.items, countries=countries, colors=colors,
                           varietals=varietals, regions=regions, next_url=next_url, prev_url=prev_url,
                           no_of_items=no_of_items)


@bp.route("/country/<country_name>")
def country(country_name):
    page = request.args.get('page', 1, type=int)
    no_of_items = get_no_of_items()
    bottles = db.session.query(Bottles).filter_by(country_name=country_name).paginate(
        page, app.config['WINES_PER_PAGE'], False)
    colors = Bottles.query.with_entities(Bottles.color_name).distinct().order_by(Bottles.color_name.asc())
    varietals = Bottles.query.with_entities(Bottles.primary_grape).distinct().order_by(Bottles.primary_grape.asc())
    countries = Countries.query.with_entities(Countries.country_name).distinct().order_by(Countries.country_name.asc())
    regions = Regions.query.with_entities(Regions.region_name).distinct().order_by(Regions.region_name.asc())
    next_url = url_for('products.country', country_name=country_name, page=bottles.next_num) if bottles.has_next else None
    prev_url = url_for('products.country', country_name=country_name, page=bottles.prev_num) if bottles.has_prev else None
    return render_template('results.jinja2', bottles=bottles.items, ccountries=countries, colors=colors,
                           varietals=varietals, regions=regions, next_url=next_url, prev_url=prev_url,
                           no_of_items=no_of_items)


@bp.route("/region/<region_name>")
def region(region_name):
    page = request.args.get('page', 1, type=int)
    no_of_items = get_no_of_items()
    bottles = db.session.query(Bottles).filter_by(region_name=region_name).paginate(
        page, app.config['WINES_PER_PAGE'], False)
    colors = Bottles.query.with_entities(Bottles.color_name).distinct().order_by(Bottles.color_name.asc())
    varietals = Bottles.query.with_entities(Bottles.primary_grape).distinct().order_by(Bottles.primary_grape.asc())
    countries = Countries.query.with_entities(Countries.country_name).distinct().order_by(Countries.country_name.asc())
    regions = Regions.query.with_entities(Regions.region_name).distinct().order_by(Regions.region_name.asc())
    next_url = url_for('products.region', region_name=region_name, page=bottles.next_num) if bottles.has_next else None
    prev_url = url_for('products.region', region_name=region_name, page=bottles.prev_num) if bottles.has_prev else None
    return render_template('results.jinja2', bottles=bottles.items, countries=countries, colors=colors,
                           varietals=varietals, regions=regions, next_url=next_url, prev_url=prev_url,
                           no_of_items=no_of_items)
