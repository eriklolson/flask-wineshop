from flask import current_app as app, Blueprint, render_template, session, g
# from flask_login import current_user
from . import bp
from flask_wineshop.cart.helpers import get_no_of_items


@bp.route('/')
@bp.route('/index')
def index():
    """Homepage route."""
    no_of_items = get_no_of_items()

    return render_template(
        'index.jinja2',
        breadcrums='home', no_of_items=no_of_items)
