"""Models"""
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from flask import Flask, current_app as app, flash
from flask_login import UserMixin, current_user
from . import db
# from flask_wineshop.api.api import *


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, nullable=False, unique=True)
    email = db.Column(db.String(120), index=True, nullable=False, unique=True)
    password = db.Column(db.String(128), nullable=False, unique=True)
    date_joined = db.Column(db.DateTime, index=True, default=datetime.utcnow, nullable=True, unique=False)
    last_login = db.Column(db.DateTime, index=True, default=datetime.utcnow, nullable=True, unique=False)
    # relationships
    cart = db.relationship('Cart', back_populates='buyer', lazy='joined')

    def __repr__(self):
        return '<User {}>'.format(self.username)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def json(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'date_joined': self.date_joined,
            'last_login': self.last_login
        }


class Cart(UserMixin, db.Model):
    __tablename__ = 'cart'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    bottles_id = db.Column(db.Integer, db.ForeignKey('bottles.id'), nullable=True)
    buy_quantity = db.Column(db.Integer, nullable=True, default=1)
    # relationships
    buyer = db.relationship('User', back_populates='cart', lazy='joined')
    items = db.relationship('Bottles', back_populates='cart', lazy='joined')

    # def get_cart(user_id):
    #     cart = Cart.query.filter(Cart.user_id == user_id).all()
    #     db.session.add(cart)
    #     db.session.commit()
    def get_cart(user_id):
        cart = Bottles.query.join(Stocks, Bottles.id == Stocks.bottles_id). \
            add_columns(Stocks.quantity). \
            join(Cart, Bottles.id == Cart.bottles_id). \
            add_columns(Bottles.id, Bottles.product_name, Bottles.color_name, Bottles.primary_grape,
                        Bottles.year, Bottles.image, Bottles.price, Cart.buy_quantity). \
            filter_by(buyer=current_user).all()
        return cart

    def add(user_id, bottles_id, buy_quantity):
        item_to_add = Cart(user_id=user_id, bottles_id=bottles_id, buy_quantity=buy_quantity)
        db.session.add(item_to_add)
        db.session.commit()
        flash('Product added to cart! Success!')

    def delete_from_cart(user_id, bottles_id):
        Cart.query.filter(Cart.bottles_id == bottles_id).filter(Cart.user_id == user_id).delete()
        db.session.commit()
    #
    # def view_cart(user_id):
    #     cart = Cart.query.filter(Cart.user_id == user_id).all()
    #      if len(cart) is 0:
    #             return None
            # res = CartSchema(many=True)
            # return res.dumps(cart).data
    #

    # def get_no_of_items(self):
    #     if current_user.is_authenticated:
    #         no_of_items = Cart.query.filter_by(buyer=current_user).count()
    #     else:
    #         no_of_items = 0
    #     return no_of_items

    def __repr__(self):
        return f"Cart('{self.id}', '{self.bottles_id}, '{self.user_id}', '{self.buy_quantity}'))"

    def json(self):
        return {
            'user_id': self.user_id,
            'bottles_id': self.bottles_id,
            'buy_quantity': self.buy_quantity
        }


class Order(UserMixin, db.Model):
    __tablename__ = 'order'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    order_date = db.Column(db.DateTime, nullable=False)
    order_total = db.Column(db.DECIMAL, nullable=False)

    def __repr__(self):
        return f"Order('{self.id}', '{self.user_id}','{self.order_date}','{self.order_total}')"


class OrderedItems(UserMixin, db.Model):
    __tablename__ = 'order_items'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    bottles_id = db.Column(db.Integer, db.ForeignKey('bottles.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=True)

    def __repr__(self):
        return f"Order('{self.id}', '{self.order_id}','{self.bottles_id}','{self.quantity}', '{self.item_price}')"


class Transactions(UserMixin, db.Model):
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer,db.ForeignKey('order.id'), nullable=False)
    transaction_date = db.Column(db.DateTime,nullable=False)
    transaction_total = db.Column(db.DECIMAL, nullable=False)
    card_number = db.Column(db.String(50), nullable=False)
    card_type = db.Column(db.String(50), nullable=False)
    response = db.Column(db.String(50), nullable=True)

    def __repr__(self):
        return f"Order('{self.id}', '{self.order_id}','{self.transaction_date}','{self.transaction_total}'," \
               f"'{self.card_number}'), '{self.card_type}', '{self.response}')"


class Bottles(UserMixin, db.Model):
    __tablename__ = 'bottles'
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(120), nullable=False)
    year = db.Column(db.String(120), nullable=False)
    volume = db.Column(db.String(120), nullable=False)
    proof = db.Column(db.String(120), nullable=False)
    producer_name = db.Column(db.String(120), nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('countries.id'))
    country_name = db.Column(db.String(120), nullable=False)
    region_name = db.Column(db.String(120), nullable=False)
    region_id = db.Column(db.Integer, db.ForeignKey('regions.id'))
    appellation = db.Column(db.String(120), nullable=False)
    color_name = db.Column(db.String(120), nullable=False)
    primary_grape = db.Column(db.String(120), nullable=False)
    all_grape = db.Column(db.String(120), nullable=False)
    price = db.Column(db.String(120), nullable=False)
    image = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    # relationships
    countries = db.relationship('Countries', back_populates='bottles')
    regions = db.relationship('Regions', back_populates='bottles')
    inventory = db.relationship('Stocks', back_populates='bottle', lazy='joined', uselist=False)
    cart = db.relationship('Cart', back_populates='items', lazy='joined')

    def __repr__(self):
        return '<Bottles {}>'.format(self.product_name)


class Stocks(UserMixin, db.Model):
    __tablename__ = 'stocks'
    bottles_id = db.Column(db.Integer, db.ForeignKey('bottles.id'), primary_key=True)
    quantity = db.Column(db.Integer, nullable=False)
    # relationships
    bottle = db.relationship('Bottles', back_populates='inventory', lazy='joined')

    def __repr__(self):
        return '<Stocks {}>'.format(self.quantity)


class Countries(UserMixin, db.Model):
    __tablename__ = 'countries'
    id = db.Column(db.Integer, primary_key=True)
    country_name = db.Column(db.String(120), unique=True, nullable=False)

    bottles = db.relationship('Bottles', back_populates='countries')

    def __repr__(self):
        return '<Countries {}>'.format(self.quantity)


class Regions(UserMixin, db.Model):
    __tablename__ = 'regions'
    id = db.Column(db.Integer, primary_key=True)
    region_name = db.Column(db.String(120), unique=True, nullable=False)

    bottles = db.relationship('Bottles', back_populates='regions')

    def __repr__(self):
        return '<Regions {}>'.format(self.quantity)