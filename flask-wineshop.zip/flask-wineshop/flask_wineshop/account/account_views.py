from flask import render_template
from flask_login import login_required, current_user

from flask_wineshop.cart.helpers import get_no_of_items
from flask_wineshop.models import Bottles, Order, User, db, Cart, Countries, Stocks
from flask_wineshop.account import bp


@bp.route('/<username>/profile')
@login_required
def profile(username):
    """User profile page: shows account info"""
    user_id = current_user.id
    username = username
    no_of_items = get_no_of_items()
    return render_template('profile.jinja2', user_id=user_id, username=username, no_of_items=no_of_items)


@bp.route('/<username>/transactions')
@login_required
def transactions(username):
    """For displaying order history"""
    # user_id = current_user.id
    no_of_items = get_no_of_items()
    username = username
    orders = db.session.query(Order.id, Order.order_date, Order.order_total) \
        .filter(Order.user_id == current_user.id).all()
    return render_template('transactions.jinja2', username=username, orders=orders, no_of_items=no_of_items)