"""Routes for user authentication."""
from flask import Blueprint, session, redirect, render_template, request, url_for, flash
from flask_login import current_user, login_required, login_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wineshop.cart.helpers import get_no_of_items
from flask_wineshop import login_manager
from flask_wineshop.models import User, db
from . import bp
from .forms import SignupForm, LoginForm


@login_manager.user_loader
def user_loader(id):
    """Check if user is logged-in on every page load."""
    if id is not None:
        return User.query.get(int(id))
    return None


@login_manager.unauthorized_handler
def unauthorized():
    """Redirect unauthorized users to Login page."""
    flash('You must be logged in for that.')
    return redirect(url_for('auth.login'))


@bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    Log-in page for registered users.
    GET: Serve Log-in page.
    POST: Validate form and redirect user to index.
    """
    form = LoginForm()
    no_of_items = get_no_of_items()
    if current_user.is_authenticated:
        flash('You are already logged in')
        return redirect(url_for('home.index'))
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('auth.login'))
        login_user(user)
        flash('Welcome back! You have logged in')
        return redirect(url_for('home.index'))
    else:
        return render_template('login.jinja2', form=form, no_of_items=no_of_items)


@bp.route('/signup', methods=['GET', 'POST'])
def signup():
    """
    Register form to create new user accounts.
    GET: Serve register page.
    POST: Validate form, create account, redirect user to index.
    """
    form = SignupForm()
    no_of_items = get_no_of_items()
    if current_user.is_authenticated:
        return redirect(url_for('home.index'))
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data, method='sha256')
        username = form.username.data
        email = form.email.data
        password = hashed_password
        new_user = User(username=username, email=email, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Congratulations, you are now a registered user!')
        return redirect(url_for('home.index'))
    return render_template('signup.jinja2', form=form, no_of_items=no_of_items)


@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have logged out')
    return redirect(url_for('home.index'))



#
#
# @bp.route('/reset_password_request', methods=['GET', 'POST'])
# def reset_password_request():
#     if current_user.is_authenticated:
#         return redirect(url_for('main.index'))
#     form = ResetPasswordRequestForm()
#     if form.validate_on_submit():
#         user = User.query.filter_by(email=form.email.data).first()
#         if user:
#             send_password_reset_email(user)
#         flash(
#             _('Check your email for the instructions to reset your password'))
#         return redirect(url_for('auth.login'))
#     return render_template('auth/reset_password_request.html',
#                            title=_('Reset Password'), form=form)
#
#
# @bp.route('/reset_password/<token>', methods=['GET', 'POST'])
# def reset_password(token):
#     if current_user.is_authenticated:
#         return redirect(url_for('main.index'))
#     user = User.verify_reset_password_token(token)
#     if not user:
#         return redirect(url_for('main.index'))
#     form = ResetPasswordForm()
#     if form.validate_on_submit():
#         user.set_password(form.password.data)
#         db.session.commit()
#         flash(_('Your password has been reset.'))
#         return redirect(url_for('auth.login'))
#     return render_template('auth/reset_password.html', form=form)
#
#
