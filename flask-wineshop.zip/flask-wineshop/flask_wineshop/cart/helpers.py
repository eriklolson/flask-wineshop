from flask import request, render_template, redirect, url_for, session, flash
from flask_wineshop.models import *
import json


def get_no_of_items():
    if current_user.is_authenticated:
        no_of_items = Cart.query.filter_by(buyer=current_user).count()
    else:
        no_of_items = 0
    return no_of_items


def in_cart(bottles_id):
    user = current_user
    cart = Cart.view_cart(user.id)
    if cart is not None:
        cart = json.loads(cart)
        for bottle in cart:
            if bottles_id == bottle["id"]:
                return True
        else:
            return False
    else:
        return False


