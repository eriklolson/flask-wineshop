"""Routes for shopping cart and order"""
from flask import abort
from .forms import *
from . import bp
from .helpers import *



def get_cart(user_id):
    cart = Bottles.query.join(Stocks, Bottles.id == Stocks.bottles_id). \
        add_columns(Stocks.quantity). \
        join(Cart, Bottles.id == Cart.bottles_id). \
        add_columns(Bottles.id, Bottles.product_name, Bottles.color_name, Bottles.primary_grape,
                    Bottles.year, Bottles.image, Bottles.price, Cart.buy_quantity). \
        filter_by(buyer=current_user).all()
    return cart


@bp.route('/cart/add <int:bottles_id>', methods=['POST'])
@login_required
def add_to_cart(bottles_id):
    quantity = request.form.get('qty')
    # check if product is already in cart or not
    # if in_cart(bottles_id):
    cart = Cart.query.filter(Cart.user_id == current_user.id).all()
    if bottles_id in cart:
        # if yes, update quantity
        item = Cart.query.filter_by(bottles_id=bottles_id, buyer=current_user).first()
        item.buy_quantity += int(quantity)
        db.session.commit()
        flash('This product already in cart, quantity added!')
    # if not, add item to cart
    else:
        Cart.add(current_user.id, bottles_id, quantity)
    return redirect(url_for('cart.cart', user_id=current_user.id))


@bp.route('/cart/update <int:bottles_id>', methods=['POST'])
@login_required
def update_cart(bottles_id):
    # Update quantity of a product in cart
    item = Cart.query.filter_by(bottles_id=bottles_id, buyer=current_user).first()
    item.buy_quantity = int(request.form.get('qty'))
    db.session.commit()
    return redirect(url_for('cart.cart', user_id=current_user.id))


@bp.route('/cart/<int:user_id>', methods=['GET', 'POST'])
@login_required
def cart(user_id):
    if current_user.id != user_id:
        return abort(403)
    else:
        no_of_items = get_no_of_items()
        # display items in cart
        cart = get_cart(user_id)
        # Display total price for all items in cart
        total = 0
        for bottle in cart:
            total += float(bottle.price) * int(bottle.buy_quantity)

        if request.method == 'POST':
            bottles_id = request.form.get('bottle.id')
            qty = request.form.get('qty')
            cart_item = Cart.query.filter_by(bottles_id=bottles_id).first()
            cart_item.buy_quantity = qty
            db.session.commit()
            total = 0
            for item in cart:
                total += float(item.price) * int(item.buy_quantity)
    return render_template('cart.jinja2', cart=cart, no_of_items=no_of_items, total=total)


@bp.route('/cart/remove <int:bottles_id>')
@login_required
def remove_from_cart(bottles_id):
    # Remove product from user's shopping cart identified by product id ('bottles_id')
    item_to_remove = Cart.query.filter_by(bottles_id=bottles_id, buyer=current_user).first()
    db.session.delete(item_to_remove)
    db.session.commit()
    return redirect(url_for('cart.cart', user_id=current_user.id))


@bp.route('/create-order/<order_total>', methods=['GET', 'POST'])
@login_required
def create_order(order_total):
    form = CheckoutForm
    # Commit sales order, triggering other functions that update backend database to reflect sale

    user_id = current_user.id
    cart = get_cart(user_id)
    fullname = request.form.get('fullname')
    order_date = datetime.utcnow()
    for item in cart:
        if item.buy_quantity > item.quantity:
            flash('not enough in stock')
        else:
            stock_item = db.session.query(Stocks).filter(Stocks.bottles_id == item.id).first()
            stock_item.quantity = item.quantity - item.buy_quantity
            db.session.add(stock_item)
            db.session.flush()
            db.session.commit()
    order_id = db.session.query(Order.id).filter(Order.user_id == user_id).order_by(Order.id.desc()).first()
    order_id = order_id[0]
    order_total = order_total
    card_number = request.form.get('card_number')
    card_type = request.form.get('card_type')
    order = Order(user_id=user_id, order_date=order_date, order_total=order_total)
    db.session.add(order)
    db.session.flush()
    db.session.commit()

    update_ordered_items(order_id, user_id)
    update_transactions(order_id, order_date, order_total, card_number, card_type)
    remove_ordered_items_from_cart(user_id)

    return render_template('ordered.jinja2', fullname=fullname, order_id=order_id, order_total=order_total, form=form)